﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace First_Project_Stefanini.TestesUI.Helpers
{
    public class TestHelper
    {
        //public static string PastaDoExecutavel = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        public static string PastaDoExecutavel = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);    
    }
}
