﻿using Frist_Project_Stefanini.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Frist_Project_Stefanini.Domain.Interfaces.Services
{
    public interface ICandidatoService : IService<Candidato>
    {
    }
}
