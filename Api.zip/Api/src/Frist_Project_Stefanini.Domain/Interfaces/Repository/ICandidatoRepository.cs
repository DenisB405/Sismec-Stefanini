﻿using Frist_Project_Stefanini.ApplicarionCore.Interfaces;
using Frist_Project_Stefanini.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Frist_Project_Stefanini.Domain.Interfaces.Repository
{
    public interface ICandidatoRepository : IRepository<Candidato>
    {
    }
}
