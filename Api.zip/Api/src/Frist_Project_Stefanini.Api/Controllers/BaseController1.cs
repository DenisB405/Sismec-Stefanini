﻿namespace Frist_Project_Stefanini.Api.Controllers
{
    public class BaseController<T>
    {
    }
}