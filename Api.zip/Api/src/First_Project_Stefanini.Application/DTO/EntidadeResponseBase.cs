﻿using System;
using System.Collections.Generic;
using System.Text;

namespace First_Project_Stefanini.Application.DTO
{
    public class EntidadeResponseBase
    {
    }
}
