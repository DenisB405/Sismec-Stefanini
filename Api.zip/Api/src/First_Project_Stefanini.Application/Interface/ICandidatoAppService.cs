﻿using First_Project_Stefanini.Application.DTO.Candidato;
using Frist_Project_Stefanini.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace First_Project_Stefanini.Application.Interface
{
    public interface ICandidatoAppService: IAppServiceBase<Candidato,CandidatoRequest,CandidatoResponse>
    {

    }
}
